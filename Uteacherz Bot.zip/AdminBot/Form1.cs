﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telegram.Bot.Types;
using System.Net.NetworkInformation;
using System.Net;
using System.Drawing.Text;
using System.Diagnostics.Contracts;
using System.Net.Cache;
using System.IO;
using System.Text.RegularExpressions;
using Telegram.Bot.Types.ReplyMarkups;
using Telegram.Bot.Types.InputFiles;

namespace AdminBot
{
    public partial class Form1 : Form
    {
        private string menuNumber = "0";
        private ReplyKeyboardMarkup mainKeyboardMarkup;
        private ReplyKeyboardMarkup searchKeyboardMarkup;
        private ReplyKeyboardMarkup[] resultKeyboardMarkup = new ReplyKeyboardMarkup[3000];
        private ReplyKeyboardMarkup teacherKeyboardMarkup;
        private ReplyKeyboardMarkup numberPadKeyboardMarkup;
        private ReplyKeyboardMarkup BackKeyboardMarkup;
        private InlineKeyboardMarkup[] LikeDislikeKeyboard = new InlineKeyboardMarkup[20];
        private DataTable[] searchResult = new DataTable[3000];
        private string photosAddress = @"C:\Users\Arman\Desktop\Projects\UTeacherz\Data\photos\";
        private string adminsSavingPath = @"C:\Users\Arman\Desktop\Projects\UTeacherz\Data\photos\";
        private string blocklistSavingPath = @"C:\Users\Arman\Desktop\Projects\UTeacherz\Data\photos\";
        private string teacherID;
        private string teacherName;
        private string[,] usersInfo = new string[3000, 5];
        private int userIndex = 0;

        ITeachersRepository repository;

        private static string token = "";
        private Thread botThread;
        private Telegram.Bot.TelegramBotClient bot;
        private int counter = 0;
        private string blackList = "";
        private string adminsList = "";
        public Form1()
        {
            InitializeComponent();
            repository = new TeacherzRepository();
        }

        private void Startbtn_Click(object sender, EventArgs e)
        {
            blackList = BlocklistTextbox.Text;
            adminsList = AdminsListTextbox.Text;

            if (CheckForInternetConnection())
            {
                token = txtToken.Text;
                botThread = new Thread(new ThreadStart(RunBot));
                botThread.Start();
            }
            else
            {
                errorText.Invoke(new Action(() =>
                {
                    errorText.ForeColor = Color.Red;
                    errorText.Text = "YOU'RE OFFLINE \n\a Please check your internet connection and try later!";
                }));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 3000; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    usersInfo[i, j] = "0";
                }
            }

            #region keyboards
            // Defining the main keyboard:
            mainKeyboardMarkup = new ReplyKeyboardMarkup();
            KeyboardButton[] row1 =
            {
                new KeyboardButton("🔎 جست و جو")
            };
            KeyboardButton[] row2 =
             {
                new KeyboardButton("🏛 جامعه ی دانشگاه تهران")
            };
            KeyboardButton[] row3 =
             {
                new KeyboardButton("🗒 مطالب مفید")
            };

            mainKeyboardMarkup.Keyboard = new KeyboardButton[][]
            {
                row1, row2, row3
            };

            // Defining the main keyboard:
            BackKeyboardMarkup = new ReplyKeyboardMarkup();
            KeyboardButton[] HomeButton =
            {
                new KeyboardButton("🏛 خانه")
            };
            KeyboardButton[] BackButton =
             {
                new KeyboardButton("◀️ بازگشت")
            };

            BackKeyboardMarkup.Keyboard = new KeyboardButton[][]
            {
                HomeButton,BackButton
            };

            // number pad keyboard markup:
            numberPadKeyboardMarkup = new ReplyKeyboardMarkup();
            KeyboardButton[] r1 =
            {
                new KeyboardButton("8"),new KeyboardButton("9"),new KeyboardButton("10")
            };
            KeyboardButton[] r2 =
             {
                new KeyboardButton("5"),new KeyboardButton("6"),new KeyboardButton("7")
            };
            KeyboardButton[] r3 =
             {
                new KeyboardButton("2"),new KeyboardButton("3"),new KeyboardButton("4")
            };
            KeyboardButton[] r4 =
             {
                new KeyboardButton("◀️ بازگشت"),new KeyboardButton("0"),new KeyboardButton("1")
            };

            numberPadKeyboardMarkup.Keyboard = new KeyboardButton[][]
            {
                r1,r2,r3,r4
            };

            // search keyboard:
            searchKeyboardMarkup = new ReplyKeyboardMarkup();
            KeyboardButton[] searchRow1 =
            {
                                            new KeyboardButton("🏛 خانه")
             };
            searchKeyboardMarkup.Keyboard = new KeyboardButton[][]
            {
                                               searchRow1
             };

            mainKeyboardMarkup.ResizeKeyboard = true;
            searchKeyboardMarkup.ResizeKeyboard = true;
            numberPadKeyboardMarkup.ResizeKeyboard = true;
            BackKeyboardMarkup.ResizeKeyboard = true;

            #endregion keyboards

            //checking the connection:
            if (CheckForInternetConnection())
            {
                this.Invoke(new Action(() =>
                {
                    serverConnection.Text = "Can connect to the server";
                    serverConnection.ForeColor = Color.Green;
                }));
            }
            else
            {
                this.Invoke(new Action(() =>
                {
                    serverConnection.Text = "Can't connect to the server";
                    serverConnection.ForeColor = Color.Red;
                }));
            }
        }

        // EVERYTHING HAPPENS HERE : 
        void RunBot()
        {
        RESTART:
            bot = new Telegram.Bot.TelegramBotClient(token);
            this.Invoke(new Action(() =>
            {
                lblstatus.Text = "Connected to the server";
                lblstatus.ForeColor = Color.Green;
            }));
            errorText.Invoke(new Action(() =>
            {
                errorText.ForeColor = Color.Green;
                errorText.Text = "YOU'RE CONNECTED SUCCESSFULLY!";
            }));
            int offset = 0;
            while (true)
            {
                try
                {
                    if (CheckForInternetConnection())
                    {
                        this.Invoke(new Action(() =>
                        {
                            serverConnection.Text = "Can connect to the server";
                            serverConnection.ForeColor = Color.Green;
                        }));

                        Telegram.Bot.Types.Update[] update = bot.GetUpdatesAsync(offset).Result;

                        foreach (var up in update)
                        {
                            offset = up.Id + 1;

                            try
                            {
                                // callback query:
                                if (up.CallbackQuery != null)
                                {
                                    var from = up.CallbackQuery.From;
                                    var chatID = up.CallbackQuery.Message.Chat.Id;
                                    var messageID = up.CallbackQuery.Message.MessageId;
                                    string query = up.CallbackQuery.Data.ToString();

                                    bool found = false;
                                    int theLastEmptyIndex = 0;
                                    for (int i = 2999; i >= 0; i--)
                                    {
                                        for (int j = 0; j < 3; j++)
                                        {
                                            if (usersInfo[i, 0] == "0")
                                            {
                                                theLastEmptyIndex = i;
                                            }
                                            else if (usersInfo[i, 0] == chatID.ToString())
                                            {
                                                found = true;
                                                userIndex = i;
                                                teacherID = usersInfo[i, 1];
                                                teacherName = usersInfo[i, 2];
                                                menuNumber = usersInfo[i, 3];
                                            }
                                        }
                                    }
                                    if (!found)
                                    {
                                        usersInfo[theLastEmptyIndex, 0] = chatID.ToString();
                                        usersInfo[theLastEmptyIndex, 3] = "0";
                                        userIndex = theLastEmptyIndex;
                                    }

                                    if (query.Contains("Delete"))
                                    {
                                        string[] deleteData = query.Replace("Delete", "").Split('#');
                                        string deleteID = deleteData[0];
                                        string deleteCommentNumber = deleteData[1];
                                        string deleteName = deleteData[2];

                                        DataTable deleteTable = SearchSQL(deleteName);

                                        if (deleteTable.Rows[0]["comment" + deleteCommentNumber].ToString().Length > 10)
                                        {
                                            UpdateCommentSQL(deleteID, "", deleteTable.Rows[0]["comment_id"].ToString(), "Admin Deleted", "Arman", "Hajmohammadi", deleteCommentNumber);
                                            UpdateLikeSQL(deleteID, 0.ToString(), 0.ToString(), "", "", deleteCommentNumber, "Admin Deleted", "Arman", "Hajmohammadi");
                                        }
                                        bot.EditMessageReplyMarkupAsync(up.CallbackQuery.Message.Chat.Id,
                                                                                                    up.CallbackQuery.Message.MessageId, null);

                                        bot.AnswerCallbackQueryAsync(up.CallbackQuery.Id);

                                        continue;

                                    }

                                    if (menuNumber == "3" && usersInfo[userIndex, 4] == teacherName)
                                    {
                                        if (query.Contains("Dislike"))
                                        {
                                            string queryNumber = query.Replace("Dislike", "");

                                            searchResult[userIndex] = SearchSQL(teacherName);
                                            teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                            teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                            usersInfo[userIndex, 1] = teacherID;
                                            usersInfo[userIndex, 2] = teacherName;

                                            if (searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes_id"].ToString().Contains(chatID.ToString()))
                                            {
                                                UpdateLikeSQL(teacherID,
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes"]) - 1).ToString(),
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes"]) + 1).ToString(),
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes_id"].ToString().Replace(chatID.ToString() + "#", ""),
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes_id"].ToString() + chatID.ToString() + "#",
                                                    queryNumber, from.Username, from.FirstName, from.LastName);
                                            }
                                            else if (!searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes_id"].ToString().Contains(chatID.ToString()))
                                            {
                                                UpdateLikeSQL(teacherID,
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes"])).ToString(),
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes"]) + 1).ToString(),
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes_id"].ToString(),
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes_id"].ToString() + chatID.ToString() + "#",
                                                    queryNumber, from.Username, from.FirstName, from.LastName);
                                            }

                                            //the keyboard:
                                            searchResult[userIndex] = SearchSQL(teacherName);
                                            var LikeDislike = new InlineKeyboardButton[1][];
                                            var keyboardButtons = new InlineKeyboardButton[3];
                                            keyboardButtons[0] = new InlineKeyboardButton
                                            {
                                                Text = "👍 " + "(" + searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes"].ToString() + ")",
                                                CallbackData = "Like" + queryNumber,
                                            };
                                            keyboardButtons[1] = new InlineKeyboardButton
                                            {
                                                Text = "👎 " + "(" + searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes"].ToString() + ")",
                                                CallbackData = "Dislike" + queryNumber,
                                            };
                                            keyboardButtons[2] = new InlineKeyboardButton
                                            {
                                                Text = "⚠️ گزارش",
                                                CallbackData = "Report" + queryNumber,
                                            };
                                            LikeDislike[0] = keyboardButtons;

                                            LikeDislikeKeyboard[Convert.ToInt32(queryNumber)] = new InlineKeyboardMarkup(LikeDislike);

                                            bot.EditMessageReplyMarkupAsync(up.CallbackQuery.Message.Chat.Id,
                                                                                                        up.CallbackQuery.Message.MessageId,
                                                                                                        LikeDislikeKeyboard[Convert.ToInt32(queryNumber)]);
                                            bot.AnswerCallbackQueryAsync(up.CallbackQuery.Id);
                                            continue;
                                        }
                                        else if (query.Contains("Like"))
                                        {
                                            string queryNumber = query.Replace("Like", "");

                                            searchResult[userIndex] = SearchSQL(teacherName);
                                            teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                            teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                            usersInfo[userIndex, 1] = teacherID;
                                            usersInfo[userIndex, 2] = teacherName;

                                            if (searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes_id"].ToString().Contains(chatID.ToString()))
                                            {
                                                UpdateLikeSQL(teacherID,
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes"]) + 1).ToString(),
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes"]) - 1).ToString(),
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes_id"].ToString() + chatID.ToString() + "#",
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes_id"].ToString().Replace(chatID.ToString() + "#", ""),
                                                    queryNumber, from.Username, from.FirstName, from.LastName);
                                            }
                                            else if (!searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes_id"].ToString().Contains(chatID.ToString()))
                                            {
                                                UpdateLikeSQL(teacherID,
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes"]) + 1).ToString(),
                                                    (Convert.ToInt32(searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes"])).ToString(),
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes_id"].ToString() + chatID.ToString() + "#",
                                                    searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes_id"].ToString(),
                                                    queryNumber, from.Username, from.FirstName, from.LastName);
                                            }

                                            //the keyboard:
                                            searchResult[userIndex] = SearchSQL(teacherName);
                                            var LikeDislike = new InlineKeyboardButton[1][];
                                            var keyboardButtons = new InlineKeyboardButton[3];
                                            keyboardButtons[0] = new InlineKeyboardButton
                                            {
                                                Text = "👍 " + "(" + searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes"].ToString() + ")",
                                                CallbackData = "Like" + queryNumber,
                                            };
                                            keyboardButtons[1] = new InlineKeyboardButton
                                            {
                                                Text = "👎 " + "(" + searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes"].ToString() + ")",
                                                CallbackData = "Dislike" + queryNumber,
                                            };
                                            keyboardButtons[2] = new InlineKeyboardButton
                                            {
                                                Text = "⚠️ گزارش",
                                                CallbackData = "Report" + queryNumber,
                                            };
                                            LikeDislike[0] = keyboardButtons;

                                            LikeDislikeKeyboard[Convert.ToInt32(queryNumber)] = new InlineKeyboardMarkup(LikeDislike);

                                            bot.EditMessageReplyMarkupAsync(up.CallbackQuery.Message.Chat.Id,
                                                                                                        up.CallbackQuery.Message.MessageId,
                                                                                                        LikeDislikeKeyboard[Convert.ToInt32(queryNumber)]);
                                            bot.AnswerCallbackQueryAsync(up.CallbackQuery.Id);
                                            continue;
                                        }
                                        else if (query.Contains("Report"))
                                        {
                                            if (from.Username != null && adminsList.Contains(from.Username.ToString().ToLower()))
                                            {
                                                StringBuilder sb = new StringBuilder();
                                                sb.AppendLine("ادمین عزیز");
                                                sb.AppendLine("مرسی بابت زحمت هایی که میکشی 🥰🤝");
                                                sb.AppendLine("کامنت با موفقیت حذف شد ✅");
                                                bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, teacherKeyboardMarkup);

                                                string queryNumber = query.Replace("Report", "");
                                                searchResult[userIndex] = SearchSQL(teacherName);
                                                teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                                usersInfo[userIndex, 1] = teacherID;
                                                usersInfo[userIndex, 2] = teacherName;

                                                DataTable deleteTable = SearchSQL(teacherName);

                                                if (deleteTable.Rows[0]["comment" + queryNumber].ToString().Length > 10)
                                                {
                                                    if (from.FirstName != null && from.LastName != null)
                                                    {
                                                        UpdateCommentSQL(teacherID, "", deleteTable.Rows[0]["comment_id"].ToString(), "Admin Deleted", from.FirstName.ToString(), from.LastName.ToString(), queryNumber);
                                                        UpdateLikeSQL(teacherID, 0.ToString(), 0.ToString(), "", "", queryNumber, "Admin Deleted", from.FirstName.ToString(), from.LastName.ToString());

                                                    }
                                                    else if (from.LastName != null)
                                                    {
                                                        UpdateCommentSQL(teacherID, "", deleteTable.Rows[0]["comment_id"].ToString(), "Admin Deleted", "", from.LastName.ToString(), queryNumber);
                                                        UpdateLikeSQL(teacherID, 0.ToString(), 0.ToString(), "", "", queryNumber, "Admin Deleted", "", from.LastName.ToString());

                                                    }
                                                    else if (from.FirstName != null)
                                                    {
                                                        UpdateCommentSQL(teacherID, "", deleteTable.Rows[0]["comment_id"].ToString(), "Admin Deleted", from.FirstName.ToString(), "", queryNumber);
                                                        UpdateLikeSQL(teacherID, 0.ToString(), 0.ToString(), "", "", queryNumber, "Admin Deleted", from.FirstName.ToString(), "");

                                                    }
                                                    else
                                                    {
                                                        UpdateCommentSQL(teacherID, "", deleteTable.Rows[0]["comment_id"].ToString(), "Admin Deleted", "Unknown", "Admin", queryNumber);
                                                        UpdateLikeSQL(teacherID, 0.ToString(), 0.ToString(), "", "", queryNumber, "Admin Deleted", "Uknown", "Admin");

                                                    }
                                                }

                                                bot.EditMessageReplyMarkupAsync(up.CallbackQuery.Message.Chat.Id,
                                                                                                            up.CallbackQuery.Message.MessageId, null);

                                                bot.AnswerCallbackQueryAsync(up.CallbackQuery.Id);

                                            }
                                            else
                                            {
                                                StringBuilder sb = new StringBuilder();
                                                sb.AppendLine("گزارش شما با موفقیت ثبت شد ✅");
                                                bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, teacherKeyboardMarkup);

                                                string queryNumber = query.Replace("Report", "");
                                                searchResult[userIndex] = SearchSQL(teacherName);
                                                teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                                usersInfo[userIndex, 1] = teacherID;
                                                usersInfo[userIndex, 2] = teacherName;


                                                //the keyboard:
                                                InlineKeyboardMarkup reportToAdminKeyboard;
                                                var reportToAdminKeys = new InlineKeyboardButton[1][];
                                                var keyboardButtons = new InlineKeyboardButton[1];
                                                keyboardButtons[0] = new InlineKeyboardButton
                                                {
                                                    Text = "❌ حذف",
                                                    CallbackData = "Delete" + teacherID + "#" + queryNumber + "#" + teacherName,
                                                };

                                                reportToAdminKeys[0] = keyboardButtons;

                                                reportToAdminKeyboard = new InlineKeyboardMarkup(reportToAdminKeys);


                                                StringBuilder reportToAdmin = new StringBuilder();
                                                reportToAdmin.AppendLine("⚠️ گزارش");
                                                reportToAdmin.AppendLine("Teacher id: " + teacherID);
                                                reportToAdmin.AppendLine("Teacher name: " + teacherName);
                                                reportToAdmin.AppendLine("comment number: " + queryNumber);
                                                reportToAdmin.AppendLine("comment:");
                                                reportToAdmin.AppendLine(searchResult[userIndex].Rows[0]["comment" + queryNumber].ToString());
                                                if (from.Username != null)
                                                {
                                                    reportToAdmin.AppendLine("");
                                                    reportToAdmin.AppendLine("Report submitted by: " + from.Username.ToString());
                                                }
                                                reportToAdmin.AppendLine("");
                                                reportToAdmin.AppendLine("Reporter chat ID: " + up.CallbackQuery.Message.Chat.Id.ToString());
                                                bot.SendTextMessageAsync(1372337085, reportToAdmin.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, false, false, 0, false, reportToAdminKeyboard);
                                                //the keyboard:
                                                searchResult[userIndex] = SearchSQL(teacherName);
                                                var LikeDislike = new InlineKeyboardButton[1][];
                                                keyboardButtons = new InlineKeyboardButton[3];
                                                keyboardButtons[0] = new InlineKeyboardButton
                                                {
                                                    Text = "👍 " + "(" + searchResult[userIndex].Rows[0]["comment" + queryNumber + "_likes"].ToString() + ")",
                                                    CallbackData = "Like" + queryNumber,
                                                };
                                                keyboardButtons[1] = new InlineKeyboardButton
                                                {
                                                    Text = "👎 " + "(" + searchResult[userIndex].Rows[0]["comment" + queryNumber + "_dislikes"].ToString() + ")",
                                                    CallbackData = "Dislike" + queryNumber,
                                                };
                                                keyboardButtons[2] = new InlineKeyboardButton
                                                {
                                                    Text = "⚠️ گزارش",
                                                    CallbackData = "Report" + queryNumber,
                                                };
                                                LikeDislike[0] = keyboardButtons;

                                                LikeDislikeKeyboard[Convert.ToInt32(queryNumber)] = new InlineKeyboardMarkup(LikeDislike);

                                                bot.EditMessageReplyMarkupAsync(up.CallbackQuery.Message.Chat.Id,
                                                                                                            up.CallbackQuery.Message.MessageId,
                                                                                                            LikeDislikeKeyboard[Convert.ToInt32(queryNumber)]);
                                                bot.AnswerCallbackQueryAsync(up.CallbackQuery.Id);

                                            }
                                            continue;
                                        }
                                        else
                                        {
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        bot.AnswerCallbackQueryAsync(up.CallbackQuery.Id);

                                        continue;
                                    }
                                }
                            }
                            catch
                            {
                                continue;
                            }

                            //null messages: 

                            if (up.Message == null)
                            {
                                continue;
                            }
                            else
                            {
                                var from = up.Message.From;
                                var chatID = up.Message.Chat.Id;
                                var messageID = up.Message.MessageId;

                                if (blackList.Contains(chatID.ToString()))
                                {
                                    continue;
                                }


                                bool found = false;
                                int theLastEmptyIndex = 0;
                                for (int i = 2999; i >= 0; i--)
                                {
                                    for (int j = 0; j < 3; j++)
                                    {
                                        if (usersInfo[i, 0] == "0")
                                        {
                                            theLastEmptyIndex = i;
                                        }
                                        else if (usersInfo[i, 0] == chatID.ToString())
                                        {
                                            found = true;
                                            userIndex = i;
                                            teacherID = usersInfo[i, 1];
                                            teacherName = usersInfo[i, 2];
                                            menuNumber = usersInfo[i, 3];
                                        }
                                    }
                                }
                                if (!found)
                                {
                                    usersInfo[theLastEmptyIndex, 0] = chatID.ToString();
                                    usersInfo[theLastEmptyIndex, 3] = "0";
                                    userIndex = theLastEmptyIndex;
                                }

                                // text messages:
                                if (up.Message.Text != null)
                                {
                                    var text = up.Message.Text.ToLower();

                                    try
                                    {
                                        // ✅Start:
                                        if (text.Contains("/start"))
                                        {
                                            StringBuilder sb = new StringBuilder();

                                            // The message:
                                            sb.AppendLine("سلام " + from.FirstName + " " + from.LastName + " ☺️");
                                            sb.AppendLine("امیدوارم برات مفید باشم و بتونم بهت کمک کنم 😌");
                                            sb.AppendLine("اگرم کمکی ازم بر نیومد، سوالت رو توی [گروه دانشگاه تهران](t.me/UTGroups) بپرس، دانشجو های دیگه هستن و حتما جواب سوالت رو پیدا می کنی :)");

                                            // Sending the message:
                                            bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, mainKeyboardMarkup);

                                            // Reporting the action in data grid view:
                                            dgReport.Invoke(new Action(() =>
                                            {
                                                dgReport.Rows.Add(from.Username,
                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                counter++;
                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                            }));

                                            menuNumber = "0";
                                            usersInfo[userIndex, 3] = menuNumber;

                                            continue;
                                        }

                                        // ✅Home:
                                        if (text.Contains("/home") || text.Contains("🏛 خانه"))
                                        {
                                            // Sending the message:
                                            bot.SendTextMessageAsync(chatID, "چه کاری می تونم برات انجام بدم؟ 🙂", Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, mainKeyboardMarkup);

                                            // Reporting the action in data grid view:
                                            dgReport.Invoke(new Action(() =>
                                            {
                                                dgReport.Rows.Add(from.Username,
                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                counter++;
                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                            }));
                                            menuNumber = "0";
                                            usersInfo[userIndex, 3] = menuNumber;
                                            continue;
                                        }

                                        switch (menuNumber)
                                        {
                                            case "0":

                                                // ✅Searching for teachers:
                                                if (text.ToLower().Contains("/search") || text.Contains("🔎 جست و جو"))
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("لطفا اسم استاد مد نظرت رو برام بفرست 🙂");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, searchKeyboardMarkup);

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));

                                                    menuNumber = "1";
                                                    usersInfo[userIndex, 3] = menuNumber;
                                                    continue;
                                                }

                                                // ✅usefull content:
                                                if (text.ToLower().Contains("/content") || text.Contains("🗒 مطالب مفید"))
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // the message:
                                                    sb.AppendLine("لینک ها:");
                                                    sb.AppendLine("⭕️ [لیست سامانه های مهم دانشگاه](https://t.me/UT_Guide/16)");
                                                    sb.AppendLine("⭕️ [کانال های تلگرامی دانلود کتاب دانشگاهی](https://t.me/UT_Guide/65)");
                                                    sb.AppendLine("");
                                                    sb.AppendLine("دانستنی ها:");
                                                    sb.AppendLine("💡 [کهاد چیه؟](https://t.me/UT_Guide/19)");
                                                    sb.AppendLine("💡 [دو وجهی چیه؟](https://t.me/UT_Guide/22)");
                                                    sb.AppendLine("💡 [دو رشته ای چیه؟](https://t.me/UT_Guide/24)");
                                                    sb.AppendLine("💡[تغییر رشته در مقطع کارشناسی؟](https://t.me/UT_Guide/26)");
                                                    sb.AppendLine("💡 دانستنی های اندک ترم ای ها:");
                                                    sb.AppendLine("🔺 [قسمت اول](https://t.me/UT_Guide/60) (گلستان، ایلرن، کلاس آنلاین)");
                                                    sb.AppendLine("🔺 [قسمت دوم](https://t.me/UT_Guide/62) (ایمیل دانشگاه، تی ای)");
                                                    sb.AppendLine("🔺[قسمت سوم](https://t.me/UT_Guide/66) (معرفی دانشکده ادبیات)");
                                                    sb.AppendLine("🔺[قسمت چهارم](https://t.me/UT_Guide/67) (معرفی پردیس فنی)");
                                                    sb.AppendLine("🔺 [قسمت پنجم](https://t.me/UT_Guide/69) (المپیاد دانشجویی)");
                                                    sb.AppendLine("🔺 [قسمت ششم](https://t.me/UT_Guide/70) (خوابگاه کارشناسی)");
                                                    sb.AppendLine("🔺 [قسمت هفتم](https://t.me/UT_Guide/79) (ریاضی یک)");
                                                    sb.AppendLine("🔺 [قسمت هشتم](https://t.me/UT_Guide/82) (فیزیک یک)");
                                                    sb.AppendLine("🔺 [قسمت نهم](https://t.me/UT_Guide/83) (خرید کتب دانشگاهی)");
                                                    sb.AppendLine("");
                                                    sb.AppendLine("🔶 به درد بخور ها:");
                                                    sb.AppendLine("🔸 [دفتر تلفن دانشگاه تهران](https://t.me/UT_Guide/33)");
                                                    sb.AppendLine("🔸 [نرم افزار دانشگاه تهران](https://t.me/UT_Guide/53)");
                                                    sb.AppendLine("🔸 [نحوه ی ورود به سامانه گلستان](https://t.me/UT_Guide/45)");
                                                    sb.AppendLine("🔸 [لیست گزارش های مهم سامانه گلستان](https://t.me/UT_Guide/59)");
                                                    sb.AppendLine("🔸 [توضیح در مورد کارگاه مهارت های زندگی](https://t.me/UT_Guide/77)");
                                                    sb.AppendLine("🔸 [اطلاعیه کارگاه مهارت های زندگی](https://t.me/UT_Guide/85)");
                                                    sb.AppendLine("🔸 [اتصال ایمیل دانشگاهی به نرم افزار ایمیل](https://t.me/UT_Guide/76)");
                                                    sb.AppendLine("🔸 [رفع مشکل میکروفون و وبکم در کلاس آنلاین](https://t.me/UT_Guide/84)");
                                                    sb.AppendLine("🔸 [نرم افزار های اسکن و ادغام PDF](https://t.me/UT_Guide/36)");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, mainKeyboardMarkup);

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));

                                                    continue;
                                                }

                                                // ✅usefull channels:
                                                if (text.ToLower().Contains("/channel") || text.Contains("🏛 جامعه ی دانشگاه تهران"))
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // the message:
                                                    sb.AppendLine("💢 [گروه دانشگاه تهران](t.me/UTGroups)");
                                                    sb.AppendLine("");
                                                    sb.AppendLine("💡 گروه های رفع اشکال : ");
                                                    sb.AppendLine("🌀 [ریاضیات دانشگاه تهران](https://t.me/fannimath) ");
                                                    sb.AppendLine("🌀 [فیزیک دانشگاه تهران](https://t.me/fanniphysics) ");
                                                    sb.AppendLine("🌀 [شیمی دانشگاه تهران](https://t.me/fannichem)");
                                                    sb.AppendLine("🌀 [برنامه نویسی دانشگاه تهران](https://t.me/ut_Debugger) ");
                                                    sb.AppendLine("🌀 [رفع اشکال مهندسی برق](https://t.me/EE_Students) ");
                                                    sb.AppendLine("");
                                                    sb.AppendLine("📢 کانال های دانشگاه تهران (همه ی رشته ها) : ");
                                                    sb.AppendLine("♦️ [راهنمای دانشگاه تهران](t.me/UT_guide) ");
                                                    sb.AppendLine("♦️ [اشیا گمشده دانشگاه تهران](t.me/ut_lostfound) ");
                                                    sb.AppendLine("♦️ [اساتید دانشگاه تهران](t.me/UTeacherz)");
                                                    sb.AppendLine("♦️ [کوی ستان](https://t.me/Kooyestan)");
                                                    sb.AppendLine("♦️ [همیار دانشگاه تهران](https://t.me/hamyarUT)");
                                                    sb.AppendLine("♦️ [کانال ut.ac](https://t.me/ut_ac) ");
                                                    sb.AppendLine("♦️ [انتخاب واحد دانشگاه تهران](https://t.me/evahedut97) ");
                                                    sb.AppendLine("");
                                                    sb.AppendLine("📢 کانال های اطلاع رسانی دانشگاه تهران (مخصوص فنی - مهندسی) : ");
                                                    sb.AppendLine("♦️ [آرشیو فیلم های دروس پایه دانشگاه تهران](http://t.me/OCpaye_98) ");
                                                    sb.AppendLine("♦️ [کانال ECETrends](t.me/ecetrends)");
                                                    sb.AppendLine("♦️ [فنی یار](https://t.me/TVUniversity) ");
                                                    sb.AppendLine("♦️ [صراط](https://t.me/utserat) ");
                                                    sb.AppendLine("♦️ [حکیم](https://t.me/hakim96_ut) ");
                                                    sb.AppendLine("♦️ [راهنمای دانشگاه](https://t.me/utguide) ");
                                                    sb.AppendLine("");
                                                    sb.AppendLine("📺 کانال ها و گروه های متفرقه(تفریحی) : ");
                                                    sb.AppendLine("🌀 [زایشگاه تهران](https://t.me/ZayeshgahTehran)");
                                                    sb.AppendLine("🌀 [یوتی موویز](https://t.me/utmovies)");
                                                    sb.AppendLine("🌀 [یوتی میوزیک ۱](https://t.me/UT_musics) ");
                                                    sb.AppendLine("🌀 [یوتی میوزیک ۲](https://t.me/utmusics)");
                                                    sb.AppendLine("🌀 [اوتاکو (گروه انیمه)](https://t.me/UT_Otakus)");
                                                    sb.AppendLine("🌀 [گروه شعر و ادبیات دانشگاه تهران](https://t.me/ut_poem_group)");
                                                    sb.AppendLine("");
                                                    sb.AppendLine("غیر ضروری: ");
                                                    sb.AppendLine("🔸 [گروه کد فراموشی غذا](https://t.me/+RGMB1KZyhlZxTYd9)");
                                                    sb.AppendLine("🔸 [گروه کهاد دانشگاه تهران](https://t.me/Kahad_UT)");
                                                    sb.AppendLine("🔸 [ورزشکاران دانشکده فنی](https://t.me/varzesh_fanni)");
                                                    sb.AppendLine("🔸 [معاونت فرهنگی فنی](https://t.me/engcultural_ut)");
                                                    sb.AppendLine("🔸 [باشگاه دانشجویان](https://t.me/utstudentsunion)");
                                                    sb.AppendLine("🔸 [کانال دانشگاه تهران دانشجو](https://t.me/daneshjo_ut)");
                                                    sb.AppendLine("🔸 [کتابخانه مرکزی دانشگاه تهران](https://t.me/UT_Central_Library)");
                                                    sb.AppendLine("🔸 [موسسه انتشارات دانشگاه تهران](https://t.me/UniversityofTehranPress)");
                                                    sb.AppendLine("🔸 [مرکز مشاوره دانشگاه تهران](https://t.me/UTcounseling)");
                                                    sb.AppendLine("🔸 [ورک شاپ دانشگاه تهران](https://t.me/UTworkshops)");
                                                    sb.AppendLine("🔸 [شورای صنفی کل دانشجویان دانشگاه تهران](https://t.me/UT_SENFI)");
                                                    sb.AppendLine("🔸 [سپیدار (بسیج دانشجویی دانشگاه تهران)](https://t.me/sepidar_ut)");
                                                    sb.AppendLine("🔸 [جامعه اسلامی دانشگاه تهران](https://t.me/JAD_ut)");
                                                    sb.AppendLine("🔸 [آرمان دانشگاه تهران](https://t.me/ut_edalatkhahi)");
                                                    sb.AppendLine("🔸 [دانشگاه تهران (نیوزلاین)](https://t.me/UT_NEWSLINE)");
                                                    sb.AppendLine("🔸 [كانال دارالقرآن دانشگاه تهران](https://t.me/SQuranH)");
                                                    sb.AppendLine("🔸 [كانال خوابگاه دانشگاه](https://t.me/khabgahut)");
                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, mainKeyboardMarkup);

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));

                                                    continue;
                                                }

                                                break;

                                            case "1":

                                                // ✅searching for the teacher:
                                                if (text.Length > 3)
                                                {
                                                    searchResult[userIndex] = SearchSQL(text);
                                                    if (searchResult[userIndex].Rows.Count == 0)
                                                    {
                                                        text = text.Replace("ی", "ي");
                                                        searchResult[userIndex] = SearchSQL(text);
                                                    }

                                                    if (searchResult[userIndex].Rows.Count == 0)
                                                    {
                                                        StringBuilder sb = new StringBuilder();

                                                        // The message:
                                                        sb.AppendLine("متاسفانه هیچ نتیجه ای برای این اسم پیدا نشد! لطفا یک اسم دیگه بهم بده 😔");

                                                        // Sending the message:
                                                        bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, searchKeyboardMarkup);

                                                        continue;
                                                    }
                                                    else
                                                    {
                                                        // result keyboard:
                                                        resultKeyboardMarkup[userIndex] = new ReplyKeyboardMarkup();
                                                        KeyboardButton[] backButtons =
                                                        {
                                                            new KeyboardButton("🏛 خانه"),new KeyboardButton("◀️ بازگشت")
                                                        };

                                                        KeyboardButton[] result0 =
                                                         {
                                                            new KeyboardButton(searchResult[userIndex].Rows[0]["name"].ToString())
                                                        };

                                                        switch (searchResult[userIndex].Rows.Count)
                                                        {
                                                            case 1:
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                    backButtons, result0
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;
                                                            case 2:
                                                                KeyboardButton[] result1case2 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                        backButtons, result0,result1case2
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;
                                                            case 3:
                                                                KeyboardButton[] result1case3 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result2case3 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                                };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                        backButtons, result0,result1case3,result2case3
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;

                                                            case 4:
                                                                KeyboardButton[] result1case4 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result2case4 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                                 };
                                                                KeyboardButton[] result3case4 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[3]["name"].ToString())
                                                                 };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                        backButtons, result0,result1case4,result2case4, result3case4
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;
                                                            case 5:
                                                                KeyboardButton[] result1case5 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result2case5 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result3case5 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[3]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result4case5 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[4]["name"].ToString())
                                                                };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                        backButtons, result0,result1case5,result2case5, result3case5, result4case5
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;

                                                            case 6:
                                                                KeyboardButton[] result1case6 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result2case6 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result3case6 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[3]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result4case6 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[4]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result5case6 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[5]["name"].ToString())
                                                                };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                        backButtons, result0,result1case6,result2case6, result3case6, result4case6, result5case6
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;

                                                            case 7:
                                                                KeyboardButton[] result1case7 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                 };
                                                                KeyboardButton[] result2case7 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result3case7 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[3]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result4case7 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[4]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result5case7 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[5]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result6case7 =
                                                                {
                                                                        new KeyboardButton(searchResult[userIndex].Rows[6]["name"].ToString())
                                                                };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                        backButtons, result0,result1case7,result2case7, result3case7, result4case7, result5case7, result6case7
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;

                                                            case 8:
                                                                KeyboardButton[] result1case8 =
                                                                {
                                                    new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                    };
                                                                KeyboardButton[] result2case8 =
                                                                {
                                                    new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                     };
                                                                KeyboardButton[] result3case8 =
                                                                {
                                                    new KeyboardButton(searchResult[userIndex].Rows[3]["name"].ToString())
                                                     };
                                                                KeyboardButton[] result4case8 =
                                                                {
                                                    new KeyboardButton(searchResult[userIndex].Rows[4]["name"].ToString())
                                                     };
                                                                KeyboardButton[] result5case8 =
                                                                {
                                                    new KeyboardButton(searchResult[userIndex].Rows[5]["name"].ToString())
                                                     };
                                                                KeyboardButton[] result6case8 =
                                                                {
                                                    new KeyboardButton(searchResult[userIndex].Rows[6]["name"].ToString())
                                                     };
                                                                KeyboardButton[] result7case8 =
                                                                {
                                                    new KeyboardButton(searchResult[userIndex].Rows[7]["name"].ToString())
                                                     };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                        backButtons, result0,result1case8,result2case8, result3case8, result4case8, result5case8, result6case8, result7case8
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;

                                                            case 9:
                                                                KeyboardButton[] result1case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result2case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result3case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[3]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result4case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[4]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result5case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[5]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result6case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[6]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result7case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[7]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result8case9 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[8]["name"].ToString())
                                                                };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                 {
                                                                    backButtons, result0,result1case9,result2case9, result3case9, result4case9, result5case9, result6case9, result7case9, result8case9
                                                                 };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;

                                                            default:
                                                                KeyboardButton[] result1case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[1]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result2case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[2]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result3case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[3]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result4case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[4]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result5case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[5]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result6case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[6]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result7case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[7]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result8case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[8]["name"].ToString())
                                                                };
                                                                KeyboardButton[] result9case10 =
                                                                {
                                                                    new KeyboardButton(searchResult[userIndex].Rows[9]["name"].ToString())
                                                                };
                                                                resultKeyboardMarkup[userIndex].Keyboard = new KeyboardButton[][]
                                                                {
                                                                    backButtons, result0,result1case10,result2case10, result3case10, result4case10, result5case10, result6case10, result7case10, result8case10, result9case10
                                                                };
                                                                resultKeyboardMarkup[userIndex].ResizeKeyboard = true;
                                                                break;
                                                        }
                                                        // sending message:
                                                        StringBuilder resultMessage = new StringBuilder();

                                                        // The message:
                                                        resultMessage.AppendLine("برای اسمی که گفتی " + searchResult[userIndex].Rows.Count.ToString() + " استاد پیدا شد :)");
                                                        resultMessage.AppendLine("کدوم استاد مد نظرته؟");

                                                        // Sending the message:
                                                        bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, resultKeyboardMarkup[userIndex]);
                                                        menuNumber = "2";
                                                        usersInfo[userIndex, 3] = menuNumber;
                                                        continue;
                                                    }
                                                }
                                                else
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("اسم استاد نمیتونه کمتر از 4 حرف باشه :)");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, searchKeyboardMarkup);
                                                    continue;
                                                }

                                            case "2":

                                                // ✅Back:
                                                if (text.Contains("◀️ بازگشت"))
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("لطفا اسم استاد مد نظرت رو برام بفرست 🙂");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, searchKeyboardMarkup);

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));

                                                    menuNumber = "1";
                                                    usersInfo[userIndex, 3] = menuNumber;
                                                    continue;
                                                }

                                                // ✅the teacher menu:
                                                if (text.Length > 3)
                                                {
                                                    searchResult[userIndex] = SearchSQL(text);
                                                    teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                    teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                                    usersInfo[userIndex, 1] = teacherID;
                                                    usersInfo[userIndex, 2] = teacherName;

                                                    // result keyboard:
                                                    teacherKeyboardMarkup = new ReplyKeyboardMarkup();
                                                    KeyboardButton[] backButtons =
                                                    {
                                                        new KeyboardButton("🏛 خانه"), new KeyboardButton("◀️ بازگشت")
                                                    };
                                                    KeyboardButton[] informationButton =
                                                    {
                                                        new KeyboardButton("ℹ️ اطلاعات استاد")
                                                    };
                                                    KeyboardButton[] markButton =
                                                    {
                                                        new KeyboardButton("💯 نمره دهی به استاد")
                                                    };
                                                    KeyboardButton[] commentButton =
                                                    {
                                                        new KeyboardButton("✍️ ثبت نظر")
                                                    };
                                                    KeyboardButton[] readCommentButton =
                                                    {
                                                        new KeyboardButton("📑 نظرات دانشجویان")
                                                    };
                                                    teacherKeyboardMarkup.Keyboard = new KeyboardButton[][]
                                                    {
                                                        backButtons, informationButton,markButton,commentButton,readCommentButton
                                                    };
                                                    teacherKeyboardMarkup.ResizeKeyboard = true;
                                                    // sending message:
                                                    StringBuilder resultMessage = new StringBuilder();

                                                    // The message:
                                                    resultMessage.AppendLine("در مورد استاد " + searchResult[userIndex].Rows[0]["name"].ToString() + " چه کمکی از دستم بر میاد؟🙃");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                    menuNumber = "3";
                                                    usersInfo[userIndex, 3] = menuNumber;
                                                    continue;
                                                }

                                                break;

                                            case "3":

                                                // ✅Back:
                                                if (text.Contains("◀️ بازگشت"))
                                                {
                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, "نتایج:", Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, resultKeyboardMarkup[userIndex]);

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));
                                                    menuNumber = "2";
                                                    usersInfo[userIndex, 3] = menuNumber;
                                                    continue;
                                                }

                                                // ✅information:
                                                if (text.Contains("ℹ️ اطلاعات استاد"))
                                                {
                                                    searchResult[userIndex] = SearchSQL(teacherName);
                                                    teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                    teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                                    usersInfo[userIndex, 1] = teacherID;
                                                    usersInfo[userIndex, 2] = teacherName;

                                                    StringBuilder sb = new StringBuilder();

                                                    // The caption:
                                                    // name:
                                                    string caption = "👤 [استاد " + searchResult[userIndex].Rows[0]["name"].ToString() + "](" + searchResult[userIndex].Rows[0]["URL"].ToString() + ")";
                                                    // Email:
                                                    if (searchResult[userIndex].Rows[0]["email"].ToString().Length > 3)
                                                    {
                                                        caption += "\n\n✉️ ایمیل استاد:\n" + searchResult[userIndex].Rows[0]["email"].ToString().Replace("@@", "@").Replace("G@", "@");
                                                    }
                                                    // degree:
                                                    if (searchResult[userIndex].Rows[0]["degree"].ToString().Length > 3)
                                                    {
                                                        caption += "\n\n🎖 درجه: " + searchResult[userIndex].Rows[0]["degree"].ToString();
                                                    }
                                                    // workplace:
                                                    if (searchResult[userIndex].Rows[0]["workplace"].ToString().Length > 3)
                                                    {
                                                        caption += "\n\n🏢 محل کار: \n" + searchResult[userIndex].Rows[0]["workplace"].ToString().Replace("پرديس دانشکده هاي فني / ", "");
                                                    }
                                                    // phone number:
                                                    if (!(searchResult[userIndex].Rows[0]["telephone"].ToString().Contains("?") || searchResult[userIndex].Rows[0]["telephone"].ToString().Contains("؟")) && searchResult[userIndex].Rows[0]["telephone"].ToString().Length > 3)
                                                    {
                                                        caption += "\n\n☎️ شماره تماس: " + searchResult[userIndex].Rows[0]["telephone"].ToString();
                                                    }
                                                    // Extra info:
                                                    /*if (searchResult[userIndex].Rows[0]["extra_info"].ToString().Length > 3 && !(searchResult[userIndex].Rows[0]["extra_info"].ToString().Contains("?") || searchResult[userIndex].Rows[0]["extra_info"].ToString().Contains("؟")))
                                                    {
                                                        caption += "\n\nاطلاعات دیگر: \n" + searchResult[userIndex].Rows[0]["extra_info"].ToString().Replace(@"\n", "");
                                                    }*/
                                                    // score:
                                                    if (searchResult[userIndex].Rows[0]["stnum"].ToString() != "0")
                                                    {
                                                        caption += "\n\n⭐️نمره ی استاد از دید دانشجویان: " + searchResult[userIndex].Rows[0]["score"].ToString() + "/10";
                                                        if (Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]) > 1)
                                                        {
                                                            caption += "\n" + searchResult[userIndex].Rows[0]["stnum"].ToString() + " نفر رای داده اند.";
                                                        }
                                                        else
                                                        {
                                                            caption += "\n" + searchResult[userIndex].Rows[0]["stnum"].ToString() + " نفر رای داده است.";
                                                        }
                                                    }
                                                    caption += "\n\n[ربات اساتید دانشگاه تهران](t.me/UTeachersBot)";
                                                    // Sending the message:
                                                    string address = photosAddress + searchResult[userIndex].Rows[0]["image_file_name"].ToString();

                                                    FileStream imageFile = System.IO.File.Open(address, FileMode.Open);
                                                    bot.SendPhotoAsync(chatID, new InputOnlineFile(imageFile, searchResult[userIndex].Rows[0]["image_file_name"].ToString()), caption, Telegram.Bot.Types.Enums.ParseMode.Markdown, null, false, 0, false, teacherKeyboardMarkup);

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));
                                                    continue;
                                                }

                                                // ✅score:
                                                if (text.Contains("💯 نمره دهی به استاد"))
                                                {
                                                    searchResult[userIndex] = SearchSQL(teacherName);
                                                    teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                    teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                                    usersInfo[userIndex, 1] = teacherID;
                                                    usersInfo[userIndex, 2] = teacherName;

                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("به عملکرد این استاد از 0 تا 10 چه نمره ای میدی؟");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, numberPadKeyboardMarkup);

                                                    menuNumber = "4";
                                                    usersInfo[userIndex, 3] = menuNumber;
                                                    continue;
                                                }

                                                // ✅comment:
                                                if (text.Contains("✍️ ثبت نظر"))
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("💢 نظرت در مورد این استاد چیه؟ ");
                                                    sb.AppendLine("🔺 اگر توی نظرت، به اسم درسی که با این استاد داشتی و نمره ای هم که گرفتی اشاره کنی، خیلی بیشتر به بقیه کمک می کنه.");
                                                    sb.AppendLine("ممنونم ازت 🥰");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, BackKeyboardMarkup);

                                                    menuNumber = "5";
                                                    usersInfo[userIndex, 3] = menuNumber;
                                                    continue;
                                                }

                                                // ✅ Reading comments:
                                                if (text.Contains("📑 نظرات دانشجویان"))
                                                {
                                                    searchResult[userIndex] = SearchSQL(teacherName);
                                                    teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                    teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                                    usersInfo[userIndex, 1] = teacherID;
                                                    usersInfo[userIndex, 2] = teacherName;

                                                    bool any_submitted_comment = true;
                                                    for (int i = 0; i < 20; i++)
                                                    {
                                                        StringBuilder sb = new StringBuilder();
                                                        // The message:
                                                        if (searchResult[userIndex].Rows[0]["comment" + (i + 1).ToString()].ToString().Length > 20)
                                                        {
                                                            any_submitted_comment = false;
                                                            // the comment
                                                            sb.AppendLine(searchResult[userIndex].Rows[0]["comment" + (i + 1).ToString()].ToString());

                                                            //the keyboard:
                                                            var LikeDislike = new InlineKeyboardButton[1][];
                                                            var keyboardButtons = new InlineKeyboardButton[3];
                                                            keyboardButtons[0] = new InlineKeyboardButton
                                                            {
                                                                Text = "👍 " + "(" + searchResult[userIndex].Rows[0]["comment" + (i + 1).ToString() + "_likes"].ToString() + ")",
                                                                CallbackData = "Like" + (i + 1).ToString(),
                                                            };
                                                            keyboardButtons[1] = new InlineKeyboardButton
                                                            {
                                                                Text = "👎 " + "(" + searchResult[userIndex].Rows[0]["comment" + (i + 1).ToString() + "_dislikes"].ToString() + ")",
                                                                CallbackData = "Dislike" + (i + 1).ToString(),
                                                            };
                                                            keyboardButtons[2] = new InlineKeyboardButton
                                                            {
                                                                Text = "⚠️ گزارش",
                                                                CallbackData = "Report" + (i + 1).ToString(),
                                                            };
                                                            LikeDislike[0] = keyboardButtons;

                                                            LikeDislikeKeyboard[i] = new InlineKeyboardMarkup(LikeDislike);
                                                            // the message:
                                                            bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, LikeDislikeKeyboard[i]);
                                                        }
                                                    }
                                                    if (any_submitted_comment)
                                                    {
                                                        StringBuilder noComment = new StringBuilder();
                                                        noComment.AppendLine("تا الان برای این استاد نظری ثبت نشده 😔");
                                                        // Sending the message:
                                                        bot.SendTextMessageAsync(chatID, noComment.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, teacherKeyboardMarkup);
                                                    }
                                                    else
                                                    {
                                                        StringBuilder theLastComment = new StringBuilder();
                                                        usersInfo[userIndex, 4] = teacherName;
                                                        theLastComment.AppendLine("💢 مهم ترین نظرات در مورد این استاد 💢");
                                                        // Sending the message:
                                                        bot.SendTextMessageAsync(chatID, theLastComment.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, teacherKeyboardMarkup);
                                                    }

                                                    menuNumber = "3";
                                                    usersInfo[userIndex, 3] = menuNumber;
                                                    continue;
                                                }

                                                break;

                                            case "4":

                                                // ✅Back:
                                                if (text.Contains("◀️ بازگشت"))
                                                {
                                                    // sending message:
                                                    StringBuilder resultMessage = new StringBuilder();

                                                    // The message:
                                                    resultMessage.AppendLine("در مورد استاد " + searchResult[userIndex].Rows[0]["name"].ToString() + " چه کمکی از دستم بر میاد؟🙃");

                                                    teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                    usersInfo[userIndex, 1] = teacherID;

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                    menuNumber = "3";
                                                    usersInfo[userIndex, 3] = menuNumber;

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));
                                                    continue;
                                                }

                                                // ✅Submit score:
                                                if (text.Length > 2)
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("عددی که وارد می کنی باید بین 0 تا 10 باشه =)");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, numberPadKeyboardMarkup);
                                                    continue;
                                                }
                                                else if (Convert.ToInt32(text) > 10)
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("عددی که وارد می کنی باید بین 0 تا 10 باشه =)");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, numberPadKeyboardMarkup);
                                                    continue;
                                                }
                                                else
                                                {
                                                    if (searchResult[userIndex].Rows[0]["score_id"].ToString().Contains(chatID.ToString()))
                                                    {
                                                        // sending message:
                                                        StringBuilder resultMessage = new StringBuilder();

                                                        // The message:
                                                        resultMessage.AppendLine("شما قبلا به این استاد نمره داده اید.");

                                                        // Sending the message:
                                                        bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                        menuNumber = "3";
                                                        usersInfo[userIndex, 3] = menuNumber;

                                                        // Reporting the action in data grid view:
                                                        dgReport.Invoke(new Action(() =>
                                                        {
                                                            dgReport.Rows.Add(from.Username,
                                                            (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                            counter++;
                                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                        }));
                                                        continue;
                                                    }
                                                    else
                                                    {
                                                        if (text.Contains("10"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 10) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("9"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 9) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("8"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 8) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("7"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 7) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("6"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 6) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("5"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 5) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("4"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 4) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("3"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 3) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("2"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 2) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("1"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 1) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;

                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                        if (text.Contains("0"))
                                                        {
                                                            int score = Convert.ToInt32(searchResult[userIndex].Rows[0]["score"]);
                                                            int stnum = Convert.ToInt32(searchResult[userIndex].Rows[0]["stnum"]);
                                                            score = (score * stnum + 0) / (stnum + 1);
                                                            stnum++;
                                                            UpdateScoreSQL(teacherID, score.ToString(), chatID.ToString() + "#", stnum.ToString(), from.Username, from.FirstName, from.LastName);
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("نمره دهی با موفقیت انجام شد ✅");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;
                                                            // Reporting the action in data grid view:
                                                            dgReport.Invoke(new Action(() =>
                                                            {
                                                                dgReport.Rows.Add(from.Username,
                                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                                dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                                counter++;
                                                                dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                            }));
                                                            continue;
                                                        }
                                                    }
                                                }

                                                break;

                                            case "5":

                                                // ✅Back:
                                                if (text.Contains("◀️ بازگشت"))
                                                {
                                                    // sending message:
                                                    StringBuilder resultMessage = new StringBuilder();

                                                    // The message:
                                                    resultMessage.AppendLine("در مورد استاد " + searchResult[userIndex].Rows[0]["name"].ToString() + " چه کمکی از دستم بر میاد؟🙃");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                    menuNumber = "3";
                                                    usersInfo[userIndex, 3] = menuNumber;

                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));
                                                    continue;
                                                }

                                                // ✅submit the comment:
                                                if (text.Length < 20)
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("نظر شما نمیتونه کمتر از 20 کاراکتر باشه.");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, BackKeyboardMarkup);
                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));
                                                    continue;
                                                }
                                                else if (text.Length > 1500)
                                                {
                                                    StringBuilder sb = new StringBuilder();

                                                    // The message:
                                                    sb.AppendLine("نظر شما نمیتونه بیشتر از 1500 کاراکتر باشه");

                                                    // Sending the message:
                                                    bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, BackKeyboardMarkup);
                                                    // Reporting the action in data grid view:
                                                    dgReport.Invoke(new Action(() =>
                                                    {
                                                        dgReport.Rows.Add(from.Username,
                                                        (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                        counter++;
                                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                    }));
                                                    continue;
                                                }
                                                else
                                                {
                                                    if (AbusiveWordChecker(text))
                                                    {
                                                        StringBuilder sb = new StringBuilder();

                                                        // The message:
                                                        sb.AppendLine("توی نظرت از یه سری الفاظ رکیک استفاده شده 🙄");
                                                        sb.AppendLine("اگر ممکنه از ادبیات ملایم تری استفاده کن ☺️");

                                                        // Sending the message:
                                                        bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Default, null, true, false, 0, false, BackKeyboardMarkup);

                                                    }
                                                    else
                                                    {
                                                        if (searchResult[userIndex].Rows[0]["comment_id"].ToString().Contains(chatID.ToString()))
                                                        {
                                                            // sending message:
                                                            StringBuilder resultMessage = new StringBuilder();

                                                            // The message:
                                                            resultMessage.AppendLine("شما قبلا در مورد این استاد نظر داده اید.");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, resultMessage.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);
                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;
                                                        }
                                                        else
                                                        {
                                                            searchResult[userIndex] = SearchSQL(teacherName);
                                                            teacherID = searchResult[userIndex].Rows[0]["id"].ToString();
                                                            teacherName = searchResult[userIndex].Rows[0]["name"].ToString();
                                                            usersInfo[userIndex, 1] = teacherID;
                                                            usersInfo[userIndex, 2] = teacherName;

                                                            UpdateCommentSQL(teacherID, "✍️ " + text, chatID.ToString() + "#", from.Username, from.FirstName, from.LastName, CommentNumber(searchResult[userIndex]));
                                                            // sending message:
                                                            StringBuilder sb = new StringBuilder();

                                                            // The message:
                                                            sb.AppendLine("نظرت با موفقیت ثبت شد ✅");
                                                            // Sending the message:
                                                            bot.SendTextMessageAsync(chatID, sb.ToString(), Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, teacherKeyboardMarkup);

                                                            StringBuilder channelPost = new StringBuilder();

                                                            // The message:
                                                            channelPost.AppendLine(("👤 استاد: " + teacherName).Replace("ي", "ی").Replace("ك", "ک"));
                                                            // workplace
                                                            if (searchResult[userIndex].Rows[0]["workplace"].ToString().Contains("/"))
                                                            {
                                                                string[] department = searchResult[userIndex].Rows[0]["workplace"].ToString().Replace("ي", "ی").Replace("ك", "ک").Split('/');
                                                                channelPost.AppendLine("🏢 " + department[1]);
                                                            }
                                                            else
                                                            {
                                                                channelPost.AppendLine("🏢 " + searchResult[userIndex].Rows[0]["workplace"].ToString().Replace("ي", "ی").Replace("ك", "ک"));
                                                            }

                                                            channelPost.AppendLine("");
                                                            channelPost.AppendLine(("✍️ نظر: ").Replace("ي", "ی"));
                                                            channelPost.AppendLine((text).Replace("ي", "ی"));
                                                            channelPost.AppendLine("");
                                                            channelPost.AppendLine("@UTGroups");

                                                            // Sending the message:
                                                            bot.SendTextMessageAsync("@uteacherz", channelPost.ToString());

                                                            menuNumber = "3";
                                                            usersInfo[userIndex, 3] = menuNumber;
                                                        }
                                                        // Reporting the action in data grid view:
                                                        dgReport.Invoke(new Action(() =>
                                                        {
                                                            dgReport.Rows.Add(from.Username,
                                                            (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                                            counter++;
                                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                                        }));
                                                        continue;
                                                    }
                                                }

                                                break;

                                            default:

                                                break;
                                        }

                                        // Sending the message:
                                        bot.SendTextMessageAsync(chatID, "چه کاری می تونم برات انجام بدم؟ 🙂", Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, mainKeyboardMarkup);

                                        // Reporting the action in data grid view:
                                        dgReport.Invoke(new Action(() =>
                                        {
                                            dgReport.Rows.Add(from.Username,
                                            (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                            counter++;
                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                        }));
                                        menuNumber = "0";
                                        usersInfo[userIndex, 3] = menuNumber;
                                        continue;
                                    }
                                    catch
                                    {
                                        // Sending the message:
                                        bot.SendTextMessageAsync(chatID, "چه کاری می تونم برات انجام بدم؟ 🙂", Telegram.Bot.Types.Enums.ParseMode.Markdown, null, true, false, 0, false, mainKeyboardMarkup);

                                        // Reporting the action in data grid view:
                                        dgReport.Invoke(new Action(() =>
                                        {
                                            dgReport.Rows.Add(from.Username,
                                            (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                            counter++;
                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                        }));
                                        menuNumber = "0";
                                        usersInfo[userIndex, 3] = menuNumber;
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        botThread.Abort();
                        errorText.Invoke(new Action(() =>
                        {
                            errorText.ForeColor = Color.Red;
                            errorText.Text = "YOU'RE OFFLINE \n\a Please check your internet connection and try later!";
                        }));
                        this.Invoke(new Action(() =>
                        {
                            lblstatus.Text = "Not connected to the server";
                            lblstatus.ForeColor = Color.Red;
                        }));
                        this.Invoke(new Action(() =>
                        {
                            serverConnection.Text = "Can't connect to the server";
                            serverConnection.ForeColor = Color.Red;
                        }));
                        System.Threading.Thread.Sleep(15000);

                        goto RESTART;
                    }
                    continue;
                }
                catch (Exception error)
                {

                    errorText.Invoke(new Action(() =>
                    {
                        errorText.ForeColor = Color.Red;
                        errorText.Text = error.Message;
                    }));

                    this.Invoke(new Action(() =>
                    {
                        lblstatus.Text = "Not connected to the server";
                        lblstatus.ForeColor = Color.Red;
                    }));
                    this.Invoke(new Action(() =>
                    {
                        serverConnection.Text = "Can't connect to the server";
                        serverConnection.ForeColor = Color.Red;
                    }));

                    System.Threading.Thread.Sleep(15000);

                    goto RESTART;
                }
            }
        }

        #region DONE
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            botThread.Abort();
        }

        private void stopbtn_Click(object sender, EventArgs e)
        {
            errorText.Invoke(new Action(() =>
            {
                errorText.ForeColor = Color.Black;
                errorText.Text = "NO ERRORS.";
            }));
            this.Invoke(new Action(() =>
            {
                lblstatus.Text = "Not connected to the server";
                lblstatus.ForeColor = Color.Red;
            }));
            if (CheckForInternetConnection())
            {
                botThread.Abort();
            }
        }

        public static bool CheckForInternetConnection()
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    using (client.OpenRead("https://telegram.org/"))
                    {
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        string Reworder(string text)
        {
            // Removing white spaces and other characters :
            text = text.Replace(" ", "");
            text = text.Replace("*", "");
            text = text.Replace("/", "");
            text = text.Replace("+", "");
            text = text.Replace("-", "");
            text = text.Replace(".", "");
            text = text.Replace("|", "");
            text = text.Replace("$", "");
            text = text.Replace("%", "");
            text = text.Replace("_", "");
            text = text.Replace("#", "");
            text = text.Replace("@", "");
            text = text.Replace("!", "");
            text = text.Replace(",", "");
            text = text.Replace("÷", "");
            text = text.Replace("×", "");
            text = text.Replace("`", "");
            text = text.Replace("\n", "");
            text = text.Replace("\t", "");
            text = text.Replace("َ", "");
            text = text.Replace("ُ", "");
            text = text.Replace("ِ", "");
            text = text.Replace("ّ", "");
            text = text.Replace("ۀ", "");
            text = text.Replace("ً", "");
            text = text.Replace("ٌ", "");
            text = text.Replace("ٍ", "");
            text = text.Replace("‌", "");
            text = text.Replace("1", "");
            text = text.Replace("2", "");
            text = text.Replace("3", "");
            text = text.Replace("4", "");
            text = text.Replace("5", "");
            text = text.Replace("6", "");
            text = text.Replace("7", "");
            text = text.Replace("8", "");
            text = text.Replace("9", "");
            text = text.Replace("0", "");

            return text;
        }

        bool AbusiveWordChecker(string text)
        {
            if (text.Contains("ک*ر") || text.Contains("ک*"))
            {
                return true;
            }

            text = Reworder(text.ToLower());

            // Checking if the text has abusive words : 

            if (text.Contains("@") || text.Contains("کسنن") || text.Contains("کصنن") || text.Contains("کسخوار") || text.Contains("کصخوار") ||
                text.Contains("کسخار") || text.Contains("کصخار") || text.Contains("خوارکصده") || text.Contains("خارکصده") ||
                text.Contains("خوارکسده") || text.Contains("خارکسده") || text.Contains("خوارکصه") || text.Contains("خوارکسه") ||
                text.Contains("خارکصه") || text.Contains("خارکسه") || text.Contains("کصکش") || text.Contains("کسکش") ||
                text.Contains("جنده") || text.Contains("جندگی") || text.Contains("گایید") || text.Contains("ننتو") ||
                text.Contains("کیرم") || text.Contains("تخمم") || text.Contains("پتیاره") || text.Contains("مادرتو") ||
                text.Contains("کیری") || text.Contains("کسشر") || text.Contains("کسوشر") || text.Contains("کصشر") ||
                text.Contains("کصوشر") || text.Contains("کسشعر") || text.Contains("کسوشعر") || text.Contains("کصوشعر") ||
                text.Contains("کصشعر") || text.Contains("تخم") || text.Contains("کیر") ||
                text.Contains("kosekhar") || text.Contains("kosnan") || text.Contains("kosenan") || text.Contains("kharkos") ||
                text.Contains("gayid") || text.Contains("jende") || text.Contains("madarjend") || text.Contains("tokhmam") ||
                text.Contains("kiram") || text.Contains("koskesh") || text.Contains("gohnakhor") || text.Contains("nanato") ||
                text.Contains("madareto") || text.Contains("petiyare") || text.Contains("petiare") || text.Contains("tkhmm") ||
                text.Contains("jnde") || text.Contains("mdreto") || text.Contains("kososher") || text.Contains("kosesher") ||
                text.Contains("kssher") || text.Contains("kossher") || text.Contains("kos") || text.Contains("جاکش") || text.Contains("گوه") ||
                text.Contains("مادرخراب") || text.Contains("فاک") || text.Contains("ریدن") || text.Contains("ریده") || text.Contains("fuck") ||
                text.Contains("ریدم"))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        private DateTime IranTime()
        {
            return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Iran Standard Time");
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                photosAddress = Path.GetFullPath(openFile.FileName).Replace("0.jpg", "");
                photosPath.Text = photosAddress;
            }
        }

        #endregion DONE

        #region SQLFUNCTION
        private DataTable SearchSQL(string parameter)
        {
            return repository.Search(parameter);
        }

        private void UpdateCommentSQL(string id, string comment, string comment_id, string username, string firstName, string lastName, string commentNumber)
        {
            bool succeeded = repository.UpdateCommentSQL(id, comment, comment_id, commentNumber);
            if (succeeded)
            {
                dgReport.Invoke(new Action(() =>
                {
                    dgReport.Rows.Add(username,
                    (firstName + " " + lastName), "Submited a new comment!",
                    IranTime().ToString("yyyy/MM/dd - HH:mm"));

                    dgReport.FirstDisplayedScrollingRowIndex = counter;
                    counter++;
                    dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                }));
            }
            else
            {
                errorText.Invoke(new Action(() =>
                {
                    errorText.ForeColor = Color.Red;
                    errorText.Text = "Couldn't submit a new comment!";
                }));
            }
        }

        private void UpdateScoreSQL(string id, string score, string score_id, string stnum, string username, string firstName, string lastName)
        {
            bool succeeded = repository.UpdateScoreSQL(id, score, stnum, score_id);
            if (succeeded)
            {
                dgReport.Invoke(new Action(() =>
                {
                    dgReport.Rows.Add(username,
                    (firstName + " " + lastName), "Submited a new score!",
                    IranTime().ToString("yyyy/MM/dd - HH:mm"));

                    dgReport.FirstDisplayedScrollingRowIndex = counter;
                    counter++;
                    dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                }));
            }
            else
            {
                errorText.Invoke(new Action(() =>
                {
                    errorText.ForeColor = Color.Red;
                    errorText.Text = "Couldn't submit a new score!";
                }));
            }
        }

        private void UpdateLikeSQL(string id, string comment_likes, string comment_dislikes, string comment_likes_id, string comment_dislikes_id, string commentNumber, string username, string firstName, string lastName)
        {
            bool succeeded = repository.UpdateLikeSQL(id, comment_likes, comment_dislikes, comment_likes_id, comment_dislikes_id, commentNumber);
            if (succeeded)
            {
                dgReport.Invoke(new Action(() =>
                {
                    dgReport.Rows.Add(username,
                    (firstName + " " + lastName), "Updated Likes & Dislikes!",
                    IranTime().ToString("yyyy/MM/dd - HH:mm"));

                    dgReport.FirstDisplayedScrollingRowIndex = counter;
                    counter++;
                    dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                }));
            }
            else
            {
                errorText.Invoke(new Action(() =>
                {
                    errorText.ForeColor = Color.Red;
                    errorText.Text = "Couldn't submit a new score!";
                }));
            }
        }

        private void DeleteSQL(string id)
        {
            bool succeeded = repository.Delete(id);
            if (succeeded)
            {
                dgReport.Invoke(new Action(() =>
                {
                    dgReport.Rows.Add("Admin",
                    ("Arman Hajmohammadi"), "Deleted a teacher!",
                    IranTime().ToString("yyyy/MM/dd - HH:mm"));

                    dgReport.FirstDisplayedScrollingRowIndex = counter;
                    counter++;
                    dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                }));
            }
            else
            {
                errorText.Invoke(new Action(() =>
                {
                    errorText.ForeColor = Color.Red;
                    errorText.Text = "Couldn't delete a teacher";
                }));

            }
        }

        private void InsertToSQL(string name, string URL, string username, string firstName, string lastName,
            string email = null, string degree = null, string workplace = null, string telephone = null,
            string image_file_name = null, string extra_info = null, string comment = null, string score = "0", string stnum = "0")
        {
            if (name != null && URL != null)
            {
                bool succeeded = repository.Insert(name, URL, email, degree, workplace, telephone,
                    image_file_name, extra_info, comment, score, stnum);
                if (succeeded)
                {
                    dgReport.Invoke(new Action(() =>
                    {
                        dgReport.Rows.Add(username,
                        (firstName + " " + lastName), "Inserted a new teacher!",
                        IranTime().ToString("yyyy/MM/dd - HH:mm"));

                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                        counter++;
                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                    }));
                }
                else
                {
                    errorText.Invoke(new Action(() =>
                    {
                        errorText.ForeColor = Color.Red;
                        errorText.Text = "Couldn't insert a new teacher!";
                    }));
                }
            }
        }

        private string CommentNumber(DataTable searchResult)
        {
            if (searchResult.Rows[0]["comment1"].ToString() == "")
            {
                return "1";
            }
            else if (searchResult.Rows[0]["comment2"].ToString() == "")
            {
                return "2";
            }
            else if (searchResult.Rows[0]["comment3"].ToString() == "")
            {
                return "3";
            }
            else if (searchResult.Rows[0]["comment4"].ToString() == "")
            {
                return "4";
            }
            else if (searchResult.Rows[0]["comment5"].ToString() == "")
            {
                return "5";
            }
            else if (searchResult.Rows[0]["comment6"].ToString() == "")
            {
                return "6";
            }
            else if (searchResult.Rows[0]["comment7"].ToString() == "")
            {
                return "7";
            }
            else if (searchResult.Rows[0]["comment8"].ToString() == "")
            {
                return "8";
            }
            else if (searchResult.Rows[0]["comment9"].ToString() == "")
            {
                return "9";
            }
            else if (searchResult.Rows[0]["comment10"].ToString() == "")
            {
                return "10";
            }
            else if (searchResult.Rows[0]["comment11"].ToString() == "")
            {
                return "11";
            }
            else if (searchResult.Rows[0]["comment12"].ToString() == "")
            {
                return "12";
            }
            else if (searchResult.Rows[0]["comment13"].ToString() == "")
            {
                return "13";
            }
            else if (searchResult.Rows[0]["comment141"].ToString() == "")
            {
                return "14";
            }
            else if (searchResult.Rows[0]["comment15"].ToString() == "")
            {
                return "15";
            }
            else if (searchResult.Rows[0]["comment16"].ToString() == "")
            {
                return "16";
            }
            else if (searchResult.Rows[0]["comment17"].ToString() == "")
            {
                return "17";
            }
            else if (searchResult.Rows[0]["comment18"].ToString() == "")
            {
                return "18";
            }
            else if (searchResult.Rows[0]["comment19"].ToString() == "")
            {
                return "19";
            }
            else if (searchResult.Rows[0]["comment20"].ToString() == "")
            {
                return "20";
            }
            else
            {
                int minimumIndex = 1;
                int minimumLike = 0;
                for (int i = 0; i < 20; i++)
                {
                    int like = Convert.ToInt32(searchResult.Rows[0]["comment" + (i + 1).ToString() + "_likes"])
                        - Convert.ToInt32(searchResult.Rows[0]["comment" + (i + 1).ToString() + "_dislikes"]);
                    if (like <= minimumLike)
                    {
                        minimumIndex = i + 1;
                    }
                }
                return minimumIndex.ToString();
            }
        }

        #endregion SQLFUNCTION

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void BlocklistTextbox_TextChanged(object sender, EventArgs e)
        {
            SaveBlockList();
        }

        private void AdminsListTextbox_TextChanged(object sender, EventArgs e)
        {
            SaveAdminsList();
        }

        private void SaveAdminsList()
        {
            adminsList = AdminsListTextbox.Text;
            // Write the string to a file.
            System.IO.StreamWriter file = new System.IO.StreamWriter(adminsSavingPath);
            file.WriteLine(adminsList);
            file.Close();

        }

        private void SaveBlockList()
        {
            blackList = BlocklistTextbox.Text;
            // Write the string to a file.
            System.IO.StreamWriter file = new System.IO.StreamWriter(blocklistSavingPath);
            file.WriteLine(blackList);
            file.Close();
        }

        private void SavingBrowseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                adminsSavingPath = Path.GetFullPath(openFile.FileName);
                blocklistSavingPath = Path.GetFullPath(openFile.FileName).Replace("admins.txt", "block.txt");
                SavingLocation.Text = adminsSavingPath.Replace("admins.txt", "");
            }
            Loading();
        }

        private void Loading()
        {
            blackList = System.IO.File.ReadAllText(blocklistSavingPath, Encoding.UTF8);
            BlocklistTextbox.Text = blackList;
            adminsList = System.IO.File.ReadAllText(adminsSavingPath, Encoding.UTF8);
            AdminsListTextbox.Text = adminsList;
        }
    }
}
