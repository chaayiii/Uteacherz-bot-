﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AdminBot
{
    interface ITeachersRepository
    {
        DataTable SelectAll();
        DataTable SelectRow(string id);
        DataTable Search(string parameter);
        bool Insert(string name, string URL, string email, string degree, string workplace, string telephone, string image_file_name, string extra_info, string comment, string score, string stnum);
        bool UpdateCommentSQL(string id, string comment, string comment_id, string commentNumber);
        bool UpdateScoreSQL(string id, string score, string stnum, string score_id);
        bool UpdateLikeSQL(string id, string comment_likes, string comment_dislikes, string comment_likes_id, string comment_dislikes_id, string commentNumber);
        bool Delete(string id);

    }
}
