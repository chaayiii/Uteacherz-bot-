﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace AdminBot
{
    class TeacherzRepository : ITeachersRepository
    {
        private string connectionString = @"Data Source = XAAS-VPS-41; Initial Catalog = UTTeacherz_DB; Integrated Security = true";
        public bool Delete(string id)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                string query = "DELETE FROM teacher WHERE id=@id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", id);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool Insert(string name, string URL, string email, string degree, string workplace, string telephone, string image_file_name, string extra_info, string comment, string score, string stnum)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                string query = "INSERT INTO teacher (name, URL, email, degree, workplace, telephone, image_file_name, extra_info, comment, score, stnum) values (@Name, @URL, @Email, @Degree, @Workplace, @Telephone, @Image_file_name, @Extra_info, @Comment, @Score, @Stnum)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@URL", URL);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Degree", degree);
                command.Parameters.AddWithValue("@Workplace", workplace);
                command.Parameters.AddWithValue("@Telephone", telephone);
                command.Parameters.AddWithValue("@Image_file_name", image_file_name);
                command.Parameters.AddWithValue("@Extra_info", extra_info);
                command.Parameters.AddWithValue("@Comment", comment);
                command.Parameters.AddWithValue("@Score", score);
                command.Parameters.AddWithValue("@Stnum", stnum);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable Search(string parameter)
        {
            string query = "SELECT * FROM teacher WHERE name like @Parameter";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            adapter.SelectCommand.Parameters.AddWithValue("@Parameter", "%" + parameter + "%");
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }

        public DataTable SelectAll()
        {
            string query = "SELECT * FROM teacher";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }

        public DataTable SelectRow(string id)
        {
            throw new NotImplementedException();
        }

        public bool UpdateCommentSQL(string id, string comment, string comment_id, string commentNumber)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                string query = "UPDATE teacher SET comment"+commentNumber+"=@Comment, comment_id=@Comment_id WHERE id=@ID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Comment", comment);
                command.Parameters.AddWithValue("@Comment_id", comment_id);
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool UpdateScoreSQL(string id, string score, string stnum, string score_id)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                string query = "UPDATE teacher SET score=@Score, stnum=@Stnum, score_id=@Score_id WHERE id=@ID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Score", score);
                command.Parameters.AddWithValue("@Stnum", stnum);
                command.Parameters.AddWithValue("@Score_id", score_id);
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool UpdateLikeSQL(string id, string comment_likes, string comment_dislikes, string comment_likes_id, string comment_dislikes_id,string commentNumber)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                string query = "UPDATE teacher SET comment" + commentNumber.ToString() + "_likes=@LIKE, comment" + commentNumber.ToString() + "_dislikes=@DISLIKE, comment" + commentNumber.ToString() + "_likes_id=@LIKEIDS, comment" + commentNumber.ToString() + "_dislikes_id=@DISLIKEIDS WHERE id=@ID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@LIKE", comment_likes);
                command.Parameters.AddWithValue("@DISLIKE", comment_dislikes);
                command.Parameters.AddWithValue("@LIKEIDS", comment_likes_id);
                command.Parameters.AddWithValue("@DISLIKEIDS", comment_dislikes_id);
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
